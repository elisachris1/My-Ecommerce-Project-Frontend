export class Country {

    id: number;
    code: String;
    name: String;



}
